import {User} from './users/models/User';


export const V0_USER_MODELS = [User];
